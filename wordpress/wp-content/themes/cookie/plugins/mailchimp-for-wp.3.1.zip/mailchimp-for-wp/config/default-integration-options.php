<?php
return array(
	'enabled'       => 0,
	'implicit'      => 0,
	'label'         => __( 'Sign me up for the newsletter!', 'mailchimp-for-wp' ),
	'precheck'      => 1,
	'css'           => 0,
	'lists'         => array(),
	'double_optin'  => 1,
	'send_welcome'  => 0,
	'update_existing' => 0,
	'replace_interests' => 0,
);